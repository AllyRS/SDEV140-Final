"""
Author:  Ally Stubbs
Date written: 7/4/23
Assignment:   M08 Final Project
Short Desc:   Multiple-choice quiz powered by Tkinter. 25 questions along with 25 minutes.
"""
import tkinter as tk
import random
import time
import tkinter.messagebox as messagebox

class QuizApp:
    # Initialize QuizApp
    def __init__(self, master):
        self.master = master
        self.isFullscreen = False
        self.master.config(bg="white")
        self.introLabel = tk.Label(master, text="Welcome! This is a basic IT quiz that should help you with learning basic information technology terms and concepts. \nYou are given feedback after every answer given in order to help you learn.\nThere are 25 questions in this quiz along with 25 minutes to complete said quiz.\nAll questions are multiple-choice. Good luck!", font=("Roboto", 12))
        self.introLabel.pack(pady=20)

        self.beginButton = tk.Button(master, text="Begin", command=self.startQuiz, font=("Roboto", 12), bg="#4CAF50", fg="white")
        self.beginButton.pack(pady=10)

        self.fullscreenButton = tk.Button(master, text="Full Screen", command=self.toggleFullscreen, font=("Roboto", 12), bg="#6f37af", fg="white")
        self.fullscreenButton.pack(pady=10)
        
        self.questionLabel = tk.Label(master, text="", wraplength=400, font=("Roboto", 14), fg="black", bg="white")
        self.questionLabel.pack()

        self.buttonsFrame = tk.Frame(master, bg="white")
        self.buttonsFrame.pack()

        self.buttons = []
        self.currentQuestion = None
        self.questions = []
        self.score = 0
        self.skipped = []
        self.timeLeft = 1500
        self.startTime = 0
        self.restarting = False

        self.resultFrame = tk.Frame(master, bg="white")
        self.resultFrame.pack()

        self.resultLabel = tk.Label(self.resultFrame, text="", font=("Roboto", 14), fg="black", bg="white")
        self.resultLabel.grid(row=0, column=0, pady=10)
        
        self.gradeLabel = tk.Label(self.resultFrame, text="", font=("Roboto", 12), fg="black", bg="white")
       
        self.percentageLabel = tk.Label(self.resultFrame, text="", font=("Roboto", 12), fg="black", bg="white")
       
        self.timeLabel = tk.Label(self.resultFrame, text="", font=("Roboto", 12), fg="black", bg="white")

        self.timerLabel = tk.Label(self.resultFrame, text="", font=("Roboto", 12), fg="black", bg="white")
        self.timerLabel.grid(row=1, column=0, pady=10)

        self.endButton = tk.Button(self.resultFrame, text="End Application", command=self.endQuiz, font=("Roboto", 12), bg="#FF0000", fg="white")
        self.endButton.grid(row=2, column=0, pady=10)

        self.totalQuestions = 0
        
        self.elapsedTime = 0
        self.timeLabel = None
        self.answerLog = []

    # Toggle between Fullscreen and Windowed
    def toggleFullscreen(self):
        if self.isFullscreen:
            # Ask for confirmation before switching to windowed mode
            response = messagebox.askyesno("Windowed Confirmation", "Do you want to switch to windowed mode?")
        else:
            # Ask for confirmation before switching to fullscreen mode
            response = messagebox.askyesno("Fullscreen Confirmation", "Do you want to switch to fullscreen mode?")

        if response:
            self.isFullscreen = not self.isFullscreen
            self.master.attributes("-fullscreen", self.isFullscreen)
            self.updateFullscreenButtonText()

    # Updates the text on the Full Screen button depending on if the screen is fullscreen
    def updateFullscreenButtonText(self):
        if self.isFullscreen:
            self.fullscreenButton.config(text="Exit Full Screen")
        else:
            self.fullscreenButton.config(text="Full Screen")

    # Starts the quiz
    def startQuiz(self):
        self.introLabel.pack_forget()
        self.beginButton.pack_forget()
        self.questionLabel.pack()
        self.buttonsFrame.pack()

        self.loadQuestions()
        self.loadQuestion()
        self.startTime = time.time()
        self.startTimer()

    # Loads the questions
    def loadQuestions(self):
        with open("questions.txt", "r") as file:
            lines = file.readlines()

        self.questions = []
        self.totalQuestions = len(lines) // 7  # Calculate the total number of questions
        for i in range(0, len(lines), 7):
            if i + 7 > len(lines):
                break
            question = lines[i].replace("Question: ", "").strip()
            answers = [lines[i+j].replace(f"Choice {j}: ", "").strip() for j in range(1, 5)]
            correctAnswer = lines[i+5].replace("Answer: ", "").strip()
            self.questions.append((question, answers, correctAnswer))


    # Loads the next question
    def loadQuestion(self):
        self.clearQuestion()

        if self.questions:
            self.resultLabel.config(text="")
            self.currentQuestion = self.questions.pop(0)
            (question, choices, _) = self.currentQuestion

            self.questionLabel.config(text=question)

            self.createButtons(len(choices))
            for i in range(len(choices)):
                self.buttons[i].config(text=choices[i], state=tk.NORMAL)

        else:
            self.showResults()

    # Clear the question and answer buttons
    def clearQuestion(self):
        self.questionLabel.config(text="")
        for button in self.buttons:
            button.destroy()
        self.buttons = []

    # Create answer buttons
    def createButtons(self, numButtons):
        for i in range(numButtons):
            button = tk.Button(self.buttonsFrame, text="", width=40, wraplength=400, bg="#E0E0E0", fg="black", font=("Roboto", 12))
            button.grid(row=i, column=0, padx=10, pady=5)
            button.bind("<Button-1>", lambda event, index=i: self.answerQuestionButton(index))
            self.buttons.append(button)

    # Handle the user's answer to a question
    def answerQuestionButton(self, index):
        for i in range(len(self.buttons)):
            self.buttons[i].config(state=tk.DISABLED)
            if i == index:
                self.buttons[i].config(bg="dark grey", fg="red")

        selectedAnswer = self.buttons[index].cget("text")
        _, choices, correctAnswer = self.currentQuestion
        isCorrect = selectedAnswer == correctAnswer

        if selectedAnswer == "":
            self.showMessage("Please select an answer before proceeding.")
            self.master.after(1000, self.loadNextQuestion)
            return

        if isCorrect:
            self.score += 1
            self.showMessage("Correct!")
        else:
            self.showMessage("Incorrect")

        self.answerLog.append((self.currentQuestion[0], selectedAnswer, isCorrect))
        self.master.after(1000, self.loadNextQuestion)

    # Load the next question or show results
    def loadNextQuestion(self):
        if self.restarting:
            self.restarting = False
            return

        self.loadQuestion()

    # Displays a message popup
    def showMessage(self, message):
        popup = tk.Toplevel()
        popup.title("Result")
        popup.geometry("200x100")

        # Get the position and size of the main application window
        app_x = self.master.winfo_x()
        app_y = self.master.winfo_y()
        app_width = self.master.winfo_width()
        app_height = self.master.winfo_height()

        # Get the screen dimensions
        screen_width = self.master.winfo_screenwidth()
        screen_height = self.master.winfo_screenheight()

        # Calculate the center position within the main application window
        x = app_x + (app_width - 200) // 2
        y = app_y + (app_height - 100) // 2

        # Check if the popup would go out of bounds horizontally
        if x + 200 > screen_width:
            x = screen_width - 200

        # Check if the popup would go out of bounds vertically
        if y + 100 > screen_height:
         y = screen_height - 100

        # Set the position of the popup
        popup.geometry(f"+{x}+{y}")

        label = tk.Label(popup, text=message)
        label.pack()
        popup.after(1000, popup.destroy)


    # Calculate the percentage of correct answers
    def calculatePercentage(self):
        if self.totalQuestions == 0:
            return 0
        percentage = (self.score / 25) * 100
        return round(percentage, 2)

    # Determine the grade based on the percentage (US Grading System)
    def getGrade(self, percentage):
        if percentage == 100:
            return "A+"
        elif 93 <= percentage <= 99:
            return "A"
        elif 90 <= percentage <= 92:
            return "A-"
        elif 87 <= percentage <= 89:
            return "B+"
        elif 83 <= percentage <= 86:
            return "B"
        elif 80 <= percentage <= 82:
            return "B-"
        elif 77 <= percentage <= 79:
            return "C+"
        elif 73 <= percentage <= 76:
            return "C"
        elif 70 <= percentage <= 72:
            return "C-"
        elif 67 <= percentage <= 69:
            return "D+"
        elif 63 <= percentage <= 66:
            return "D"
        elif 60 <= percentage <= 62:
            return "D-"
        else:
            return "F"
        
    # Display the quiz results after all questions have been answered
    def showResults(self):
        self.stopTimer()
        self.questionLabel.pack_forget()
        self.buttonsFrame.pack_forget()
        # Calculate percentage and grade
        percentage = self.calculatePercentage()
        grade = self.getGrade(percentage)
        self.percentageLabel.config(text=f"Percentage: {percentage:.2f}%")
        self.percentageLabel.grid(row=2, column=0, pady=10)
        self.gradeLabel.config(text=f"Grade: {grade}")
        self.gradeLabel.grid(row=3, column=0, pady=10)
        self.timerLabel.grid_forget()
        self.resultLabel.config(text=f"Quiz Completed!\nScore: {self.score}/25")
        self.resultLabel.grid(row=0, column=0, pady=10)
        self.elapsedTime = int(time.time() - self.startTime)
        self.timeLabel = tk.Label(self.resultFrame, text=f"Time taken: {self.elapsedTime} seconds", font=("Roboto", 12), fg="black", bg="white")
        self.timeLabel.grid(row=1, column=0, pady=10)
        self.endButton.grid(row=4, column=0, pady=10)

        # Add a Restart button
        self.restartButton = tk.Button(self.resultFrame, text="Restart Quiz", command=self.restartQuiz, font=("Roboto", 12), bg="#e758ac", fg="white")
        self.restartButton.grid(row=5, column=0, pady=10)

        # Add a View Log button
        self.logButton = tk.Button(self.resultFrame, text="View Log", command=self.showLog, font=("Roboto", 12), bg="#3498DB", fg="white")
        self.logButton.grid(row=6, column=0, pady=10)

    # Start countdown timer
    def startTimer(self):
        if self.timeLeft > 0:
            minutes = self.timeLeft // 60
            seconds = self.timeLeft % 60
            self.timerLabel.config(text=f"Time left: {minutes:02d}:{seconds:02d}")
            self.timeLeft -= 1
            self.master.after(1000, self.startTimer)
        else:
            self.stopTimer()
            self.showTimeUpMessage()

    def showTimeUpMessage(self):
        self.showMessage("Time's up!")
        self.resultLabel.config(text="Time's up!\nQuiz incomplete.")
        self.showResults()


    # Stop countdown timer
    def stopTimer(self):
        self.timerLabel.config(text="")

    # End the quiz and application
    def endQuiz(self):
        self.master.quit()
    
    def resetTimer(self):
        self.timeLeft = 1500
        self.startTime = time.time()
        self.startTimer()
    
    # Restart the quiz
    def restartQuiz(self):
        self.resultLabel.grid_forget()
        self.beginButton.pack_forget()
        self.gradeLabel.grid_forget()
        self.percentageLabel.grid_forget()
        self.restartButton.grid_forget()
        self.timeLabel.grid_forget()
        self.score = 0
        self.loadQuestions()
        self.questionLabel.pack()
        self.buttonsFrame.pack()
        self.timerLabel.grid(row=1, column=0, pady=10)
        self.loadQuestion()
        self.resetTimer()
        self.elapsedTime = 0

    # Show the answer log in a separate window
    def showLog(self):
        logWindow = tk.Toplevel(self.master)
        logWindow.title("Answer Log")
        
        # Create a Text widget to display the log entries
        self.logText = tk.Text(logWindow, font=("Helvetica", 12), wrap="word", width=50, height=20, bg="white")
        self.logText.pack(side=tk.LEFT, fill=tk.BOTH, padx=10, pady=10)

        # Create a Scrollbar and link it to the Text widget
        self.logScrollbar = tk.Scrollbar(logWindow, command=self.logText.yview)
        self.logScrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.logText.config(yscrollcommand=self.logScrollbar.set)

        # Add each entry in the log to the Text widget
        for i, entry in enumerate(self.answerLog):
            question, selectedAnswer, isCorrect = entry
            resultText = "Correct" if isCorrect else "Incorrect"
            textColor = "#2ECC71" if isCorrect else "#E74C3C"
            logEntry = f"Question {i + 1}: You chose: {selectedAnswer} - {resultText}\n"
            self.logText.insert(tk.END, logEntry, textColor)
            self.logText.insert(tk.END, "-"*50 + "\n")

        # Enable mousewheel scrolling for the Text widget
        self.logText.bind("<MouseWheel>", self.on_mousewheel)

    # Handle mouse wheel scrolling in the log window
    def on_mousewheel(self, event):
        self.logText.yview_scroll(int(-1 * (event.delta / 120)), "units")

# Main application code
root = tk.Tk()
root.title("ITQuiz")
quizApp = QuizApp(root)
root.mainloop()